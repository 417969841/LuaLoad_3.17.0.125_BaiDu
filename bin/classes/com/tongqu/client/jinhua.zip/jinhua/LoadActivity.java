package com.tongqu.client.jinhua;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.tongqu.client.game.DownLoadService;
import com.tongqu.client.game.LuaUpdateConsole;
import com.tongqu.client.game.TQLuaAndroidConsole;
import com.tongqu.client.jinhua.R;

public class LoadActivity extends Activity {

	ProgressBar progressBar;
	TextView tvPro, tvProgress, tvTips;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.hall_load_script);
		progressBar = (ProgressBar) findViewById(R.id.asyncTaskProgress);
		// tvPro = (TextView) findViewById(R.id.tv_Pro);
		tvProgress = (TextView) findViewById(R.id.tv_Progress);
		tvTips = (TextView) findViewById(R.id.tv_tips);

		Intent serviceIntent = new Intent(this, DownLoadService.class);
		this.stopService(serviceIntent);

		LuaUpdateConsole.logicScriptLoadDir();

		Intent intent = new Intent(LoadActivity.this, TQLuaAndroidConsole.getGameMainSceneClass());
		startActivity(intent);
		finish();
	}

	/**
	 * 解压下载的zip包
	 */
	public void unZipScript() {
		// File zipFile = new File(TQGameMainScene.getZipFilePath() +
		// TQGameMainScene.ScriptZipName);
		// if (zipFile.exists()) {
		// // 如果有zip包，则解压
		// UnzipAsyncTask task = new UnzipAsyncTask(LoadActivity.this,
		// TQGameMainScene.getZipFilePath() + TQGameMainScene.ScriptZipName,
		// TQGameMainScene.getScriptFilePath(), mLoadhandler);
		// task.execute();
		// }
	}

	long downloaded = 0;// 已下载文件大小
	long totalsize = 0;// 文件总大小
	long mnInitPosition = 0;// 文件初始大小

	public static final int UNZIP_SUCCESS = 1;// 解压完成

	Handler mLoadhandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.what) {
			case UNZIP_SUCCESS:
				// 解压完成
				// logicScriptLoad();
				break;
			default:
				break;
			}
		}
	};
}